import ProfileLayout from "../ui/ProfileLayout";

function Profile() {
  return <ProfileLayout />;
}

export default Profile;
