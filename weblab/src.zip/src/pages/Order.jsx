function Order() {
  return <div>Order page</div>;
}

export default Order;
