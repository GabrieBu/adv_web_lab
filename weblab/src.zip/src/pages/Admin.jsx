import AdminLayout from "../ui/AdminLayout";

function Admin() {
  return <AdminLayout />;
}

export default Admin;
