function KitchenLayout() {
  return <div></div>;
}

export default KitchenLayout;
